print()
print('[Program complete]')
print()

from IPython import embed

embed(banner1='Entering interactive shell...')
