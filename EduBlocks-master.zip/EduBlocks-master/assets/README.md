The file `node-pty.tar.gz` is a snapshot of the module from `node_modules/node-pty/` installed on a Raspberry Pi Zero/1. This is to ensure it is built with support for the `arm6l` instruction set.
