#!/bin/bash

code server
code ui

