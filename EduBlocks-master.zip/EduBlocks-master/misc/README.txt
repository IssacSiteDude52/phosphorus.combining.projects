EduBlocks is a block-based program that uses the Google blockly API to allow
children to make an easy transition from Scratch to Python. Created by the
same people as EduPython. It currently includes 2 Python librarys. One is
EduPython allowing you to control the GPIO and the other is MCPI to
interact with minecraft.
Website & Docs:
http://edupython.co.uk
